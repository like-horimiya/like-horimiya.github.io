#!/bin/bash

echo "========================================"
echo "OBS コメントオーバーレイ URL生成ツール"
echo "OBS Comment Overlay URL Generator"
echo "========================================"
echo

# [cite_start]現在のディレクトリパスを取得 [cite: 2]
FOLDER_PATH=$(cd "$(dirname "$0")"; pwd)
BASE_URL="file://${FOLDER_PATH}/niconico_comments.html"

# [cite_start]デフォルト値の設定 [cite: 2]
DEFAULT_FLOWTIME="5"
DEFAULT_COLOR="FFFFFF"
DEFAULT_FONT="Hiragino Kaku Gothic ProN, sans-serif" # macOS向けに調整
DEFAULT_SIZE="middle"

# [cite_start]インタラクティブ入力 [cite: 3]
echo "パラメータを入力してください (Enter でデフォルト値):"
echo "Enter parameters (press Enter to use default):"
echo

read -p "流れる時間(秒) / Flow time in seconds [$DEFAULT_FLOWTIME]: " INPUT_FLOWTIME
INPUT_FLOWTIME=${INPUT_FLOWTIME:-$DEFAULT_FLOWTIME}

read -p "デフォルト文字色 / Default text color [$DEFAULT_COLOR]: " INPUT_COLOR
INPUT_COLOR=${INPUT_COLOR:-$DEFAULT_COLOR}

read -p "フォント / Font family [$DEFAULT_FONT]: " INPUT_FONT
INPUT_FONT=${INPUT_FONT:-$DEFAULT_FONT}

read -p "デフォルトサイズ (small/middle/big) [$DEFAULT_SIZE]: " INPUT_SIZE
INPUT_SIZE=${INPUT_SIZE:-$DEFAULT_SIZE}

# [cite_start]URLの組み立て [cite: 3]
# URLエンコードが必要な文字（スペースなど）を簡易的に処理
ENCODED_FONT=$(echo "$INPUT_FONT" | sed 's/ /%20/g')
FINAL_URL="${BASE_URL}?flowtime=${INPUT_FLOWTIME}&color=${INPUT_COLOR}&font=${ENCODED_FONT}&size=${INPUT_SIZE}"

# [cite_start]結果の表示 [cite: 4]
echo
echo "========================================"
echo "生成されたURL / Generated URL:"
echo "========================================"
echo "$FINAL_URL"
echo

# [cite_start]クリップボードへのコピー [cite: 5]
read -p "クリップボードにコピーしますか? / Copy to clipboard? [Y/n]: " COPY_CHOICE
COPY_CHOICE=${COPY_CHOICE:-y}

if [[ "$COPY_CHOICE" =~ ^[Yy](es)?$ ]]; then
    # [cite_start]OSを判定してコピーコマンドを切り替え [cite: 5]
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        echo -n "$FINAL_URL" | pbcopy
    elif command -v wl-copy &> /dev/null; then
        # Linux (Wayland)
        echo -n "$FINAL_URL" | wl-copy
    elif command -v xclip &> /dev/null; then
        # Linux (X11)
        echo -n "$FINAL_URL" | xclip -selection clipboard
    else
        echo "クリップボードツールが見つかりませんでした (xclip または wl-copy をインストールしてください)"
    fi
    [cite_start]echo "[クリップボードにコピーしました / COPIED TO CLIPBOARD]" [cite: 6]
else
    [cite_start]echo "[コピーしませんでした / NOT COPIED]" [cite: 6]
fi

echo
echo "========================================"
[cite_start]echo "OBS での使い方 / How to use in OBS:" [cite: 7]
[cite_start]echo "1. ブラウザソースを追加 / Add Browser Source" [cite: 7]
[cite_start]echo "2. 「ローカルファイル」のチェックを外す / UNCHECK \"Local file\"" [cite: 7]
[cite_start]echo "3. URL欄に貼り付け / Paste URL in URL field" [cite: 7]
[cite_start]echo "4. 幅:1920 高さ:1080 に設定 / Set Width: 1920, Height: 1080" [cite: 7]
echo "========================================"
echo

[cite_start]read -p "Press Enter to exit..." [cite: 8]
exit 0