#!/bin/bash
# ignore.txtからHTMLファイルの除外ユーザーリストを更新するスクリプト (Linux用)
# Update excluded users list in HTML from ignore.txt (for Linux)

# 色の定義
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${CYAN}========================================${NC}"
echo -e "${CYAN}除外ユーザーリスト更新ツール${NC}"
echo -e "${CYAN}Excluded Users List Updater${NC}"
echo -e "${CYAN}========================================${NC}"
echo ""

# スクリプトのあるディレクトリに移動
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# ファイルパス
IGNORE_FILE="ignore.txt"
HTML_FILE="niconico_comments.html"
BACKUP_FILE="niconico_comments.backup.html"

# ファイルの存在確認
if [ ! -f "$IGNORE_FILE" ]; then
    echo -e "${RED}❌ エラー / Error:${NC}"
    echo -e "${RED}  ignore.txt が見つかりません${NC}"
    echo -e "${RED}  ignore.txt not found${NC}"
    echo ""
    echo -e "  場所 / Location: $SCRIPT_DIR/$IGNORE_FILE"
    echo ""
    read -p "Enterキーで終了 / Press Enter to exit..."
    exit 1
fi

if [ ! -f "$HTML_FILE" ]; then
    echo -e "${RED}❌ エラー / Error:${NC}"
    echo -e "${RED}  niconico_comments.html が見つかりません${NC}"
    echo -e "${RED}  niconico_comments.html not found${NC}"
    echo ""
    echo -e "  場所 / Location: $SCRIPT_DIR/$HTML_FILE"
    echo ""
    read -p "Enterキーで終了 / Press Enter to exit..."
    exit 1
fi

# ignore.txtを読み込む
echo -e "${YELLOW}📄 ignore.txt を読み込み中...${NC}"
echo -e "${YELLOW}   Reading ignore.txt...${NC}"
echo ""

# コメント行と空行を除外してユーザー名を取得
IGNORED_USERS=()
while IFS= read -r line || [ -n "$line" ]; do
    # 前後の空白を削除
    line=$(echo "$line" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    
    # 空行とコメント行をスキップ
    if [ -n "$line" ] && [[ ! "$line" =~ ^# ]]; then
        IGNORED_USERS+=("$line")
    fi
done < "$IGNORE_FILE"

USER_COUNT=${#IGNORED_USERS[@]}

echo -e "${GREEN}除外ユーザー数 / Excluded users: $USER_COUNT${NC}"
if [ $USER_COUNT -gt 0 ]; then
    echo ""
    echo -e "${YELLOW}除外するユーザー / Users to exclude:${NC}"
    for user in "${IGNORED_USERS[@]}"; do
        echo "  - $user"
    done
fi
echo ""

# HTMLファイルのバックアップ
echo -e "${YELLOW}💾 バックアップを作成中...${NC}"
echo -e "${YELLOW}   Creating backup...${NC}"
cp "$HTML_FILE" "$BACKUP_FILE"
echo -e "${GREEN}   ✓ バックアップ完了 / Backup created: $BACKUP_FILE${NC}"
echo ""

# JavaScript配列を生成
JS_ARRAY="const EXCLUDED_USERS = ["

if [ $USER_COUNT -eq 0 ]; then
    JS_ARRAY="${JS_ARRAY}\n            // 除外ユーザーなし / No excluded users\n        ];"
else
    JS_ARRAY="${JS_ARRAY}\n"
    for user in "${IGNORED_USERS[@]}"; do
        # JavaScriptの文字列としてエスケープ（シングルクォートとバックスラッシュ）
        escaped_user=$(echo "$user" | sed "s/\\\\/\\\\\\\\/g" | sed "s/'/\\\'/g")
        JS_ARRAY="${JS_ARRAY}            '${escaped_user}',\n"
    done
    JS_ARRAY="${JS_ARRAY}        ];"
fi

# HTMLファイルを更新
echo -e "${YELLOW}✏️  HTMLファイルを更新中...${NC}"
echo -e "${YELLOW}   Updating HTML file...${NC}"

# sedを使用して複数行の正規表現置換（GNU sed用）
if sed --version 2>/dev/null | grep -q GNU; then
    # GNU sed（Linux）
    sed -i -z "s/const EXCLUDED_USERS = \[.*\];/${JS_ARRAY}/s" "$HTML_FILE"
else
    # Perlを使用（互換性のため）
    perl -i -0pe "s/const EXCLUDED_USERS = \[.*?\];/${JS_ARRAY}/s" "$HTML_FILE"
fi

echo -e "${GREEN}   ✓ 更新完了 / Update completed${NC}"
echo ""

echo -e "${CYAN}========================================${NC}"
echo -e "${GREEN}✅ 完了 / Completed!${NC}"
echo -e "${CYAN}========================================${NC}"
echo ""
echo -e "${YELLOW}変更内容 / Changes:${NC}"
echo "  - 除外ユーザー数 / Excluded users: $USER_COUNT"
echo "  - バックアップ / Backup: $BACKUP_FILE"
echo ""
echo -e "${YELLOW}次のステップ / Next steps:${NC}"
echo "  1. OBSのブラウザソースを更新"
echo "     Refresh browser source in OBS"
echo "  2. 除外ユーザーが反映されます"
echo "     Excluded users will be applied"
echo ""
echo -e "${YELLOW}元に戻すには / To restore:${NC}"
echo "  mv $BACKUP_FILE $HTML_FILE"
echo ""

read -p "Enterキーで終了 / Press Enter to exit..."
