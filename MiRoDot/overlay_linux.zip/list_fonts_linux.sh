#!/bin/bash

echo "========================================"
echo "インストール済みフォント一覧取得ツール"
echo "Installed Font List Generator"
echo "========================================"

# 出力ファイル名
OUTPUT_FILE="font_list.txt"

# fc-list コマンドの存在確認
if ! command -v fc-list &> /dev/null; then
    echo "エラー: 'fontconfig' (fc-list) がインストールされていません。"
    if [[ "$OSTYPE" == "darwin"* ]]; then
        echo "macOSでは通常標準搭載されています。"
    else
        echo "Linuxでは 'fontconfig' パッケージをインストールしてください。"
    fi
    exit 1
fi

echo "フォント一覧を取得中... / Fetching font list..."

# フォントのフルネームを取得して重複を除去し、アルファベット順にソートして出力
# :family はフォントファミリー名を取得する指定
fc-list : family | cut -d, -f1 | sort | uniq > "$OUTPUT_FILE"

if [ $? -eq 0 ]; then
    echo "----------------------------------------"
    echo "完了！ '$OUTPUT_FILE' を作成しました。"
    echo "Done! '$OUTPUT_FILE' has been created."
    echo "----------------------------------------"
    # 中身を少し表示
    echo "最初の5行:"
    head -n 5 "$OUTPUT_FILE"
else
    echo "エラーが発生しました。"
fi

exit 0